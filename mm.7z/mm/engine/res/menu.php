﻿<a href="index.php?total">Сводная информация</a> | 
<a href="index.php?profile_list">Список профилей</a> | 
<a href="index.php?warebase">Остатки</a> | 
<a href="index.php?docs">Журнал документов</a> | 
<a href="index.php?reports">Отчеты</a>