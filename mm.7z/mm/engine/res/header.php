﻿ <table width="100%"><tr><td>Сводный менеджер</td><td align="right">:=user_caption=:, <a href="index.php?logout">выход</a></a></td></tr></table>
