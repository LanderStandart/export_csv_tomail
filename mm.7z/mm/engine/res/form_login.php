﻿<table>
 	<tr>
		<td valign="middle">
			<table>
				<form action="index.php?task=enter" method="post">
				<tr>
					<td>Имя пользователя:</td>
					<td><input name="user_name" type="text" value=":=user_name=:"></td>
				</tr>
				<tr> 
					<td>Пароль:</td>
					<td><input name="user_psw" type="password"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input name="btn" type="submit" value="Вход"></td>
				</tr>
				</form>
			</table>
			<br>:=error_msg=:<br>
		</td>
	</tr>
</table>
