<?php
$GLOBALS["DB_DATABASENAME"]="127.0.0.1:c:\\Standart-N\\base_s\\ZTRADE_S.FDB";
$GLOBALS["DB_USER"]="SYSDBA";
$GLOBALS["DB_PASSWD"]="masterkey";
?>