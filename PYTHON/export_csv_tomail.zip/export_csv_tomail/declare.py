# Строка подключение к БД

host = '192.168.67.33'
# db_file = 'E:\Clients/aibolit/aibolit28\ztrade.fdb'
db_file = 'd:\Standart-N/base_s_new/ZTRADE_S.FDB'

