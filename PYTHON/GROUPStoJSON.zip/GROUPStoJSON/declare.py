# Строка подключение к БД

host = '192.168.67.33'
#host = 'localhost'
#db_file = 'e:\Clients/UgMEDpharm/base/ZTRADE.FDB'
db_file = 'd:\Standart-N/base_s_new/ZTRADE_S.FDB'

